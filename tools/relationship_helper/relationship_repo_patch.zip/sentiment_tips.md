# Consejos rápidos para mejorar la comunicación
- Cuando notes tensión, usa una frase para **de-escalar** (ej. "siento que esto está subiendo, quiero entenderte").
- Evita responder en caliente: espera 20-30 minutos si estás muy molesto.
- Usa mensajes que expresen **tus sentimientos** (yo siento...) en vez de acusaciones (tú siempre...). 
- Agradece lo que hizo bien y reconoce errores sin justificarte demasiado.
- Planea un check-in semanal corto: 10-15 minutos para decir cómo están las cosas.
